import React from 'react';

const SpecialPage = () => {

  return (
    <div className='container' style={{paddingTop:'100px'}}>
        <div className="modal-body">
              <video autoPlay="">
                <source src="https://instagift.mactosys.com/public/assets/images/Gradient Give Away Instagram Post.mp4" type="video/mp4" height={50} width={300} />
              </video>
        </div>
    </div>
  )
}

export default SpecialPage;