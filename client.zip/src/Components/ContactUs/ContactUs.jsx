import React from 'react'
import Contact from '../Contact/Contact';

const ContactUs = () => {
    return (
        <div style={{ paddingTop: '110px' }}>
            <Contact/>
        </div>
    )
}

export default ContactUs;