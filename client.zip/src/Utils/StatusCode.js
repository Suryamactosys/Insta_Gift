const StatusCode ={
    LOADING: 'loading',
    IDEL: 'idel',
    ERROR: 'error'
};

export default StatusCode; 