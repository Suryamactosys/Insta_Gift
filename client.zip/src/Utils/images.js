import spinner from "../Assets/images/spinner.svg";
import error from "../Assets/images/error.png";

export {spinner, error};