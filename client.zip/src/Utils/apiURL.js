// export var _apiURLUser = "http://localhost:3001/user/";


export var _apiURLUser = "http://192.168.29.195:6565/insta-gift/user/";

// user-login 

// register


// aman@gmail.com
// Raj@1234


// import axios from 'axios';
// const _apiURLUser = 'http://192.168.29.195:6565/insta-gift/user/';

// export default axios.create({
//     baseURL: _apiURLUser
// });

// export const axiosPrivate = axios.create({
//     baseURL: _apiURLUser,
//     headers: { 'Content-Type': 'application/json' },
//     withCredentials: true
// });